 

Word counter
/home/eesti/Töölaud/CODEtest2/plugins/word_counter.py