# word_counter.py
from log_formatter import log_key_press  # Import the log_key_press function

word_count = 0

def count_words(key):
    global word_count
    if key == ' ':
        word_count += 1
        log_key_press(f'Word count: {word_count}')

