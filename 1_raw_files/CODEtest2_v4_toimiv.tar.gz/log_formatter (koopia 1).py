# log_formatter.py

def format_key_event(key_event):
    # Format the key event here
    # For example, return a formatted string like "[SPACE]", "[ENTER]", etc.
    pass
